# LedgerGym — public development submission data

20 synthetic episodes (10 train, 10 dev). Each episode contains
six public-only files in public/. No private/truth.json or
private/provenance.json is included.

trajectories.jsonl contains the required seven fields, including
development-mode reward. It must not be provided as feedback in
closed-mode agent evaluation. trace_index.json identifies the 60
non-oracle baseline trajectories. The main source repository holds
the generator, evaluator, tests and baseline implementations.

This is an open, synthetic development dataset, not a blinded test
or official contest certification. See SHA256SUMS.json.
